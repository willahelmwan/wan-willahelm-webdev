(function () {
    angular.module("omdbApp", ["ngRoute", "textAngular"]);
})();